datablock CameraData(Observer)
{
   mode = "Observer";
};
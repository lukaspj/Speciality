# t3d-bones-sharp
A C# version of https://github.com/crabmusket/t3d-bones

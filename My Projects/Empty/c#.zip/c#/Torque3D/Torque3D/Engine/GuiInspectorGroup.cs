using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiInspectorGroup : GuiRolloutCtrl
	{
		public GuiInspectorGroup(bool pRegister = false)
			: base(pRegister)
		{
		}

		public GuiInspectorGroup(string pName, bool pRegister = false)
			: this(false)
		{
			Name = pName;
			if (pRegister) registerObject();
		}

		public GuiInspectorGroup(string pName, string pParent, bool pRegister = false)
         : this(pName, pRegister)
		{
			CopyFrom(Sim.FindObject<SimObject>(pParent));
		}

		public GuiInspectorGroup(string pName, SimObject pParent, bool pRegister = false)
         : this(pName, pRegister)
		{
			CopyFrom(pParent);
		}

		public GuiInspectorGroup(SimObject pObj) : base(pObj)
		{
		}

		public GuiInspectorGroup(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

		protected override void CreateSimObjectPtr()
		{
			ObjectPtr = InternalUnsafeMethods.GuiInspectorGroup_create();
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiInspectorGroup_create();
         private static _GuiInspectorGroup_create _GuiInspectorGroup_createFunc;
         internal static IntPtr GuiInspectorGroup_create()
         {
         	if (_GuiInspectorGroup_createFunc == null)
         	{
         		_GuiInspectorGroup_createFunc =
         			(_GuiInspectorGroup_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiInspectorGroup_create"), typeof(_GuiInspectorGroup_create));
         	}
         
         	return  _GuiInspectorGroup_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion


      #region Properties
      
      
      
      #endregion

	}
}
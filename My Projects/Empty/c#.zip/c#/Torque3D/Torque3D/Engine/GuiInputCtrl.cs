using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiInputCtrl : GuiMouseEventCtrl
	{
		public GuiInputCtrl(bool pRegister = false)
			: base(pRegister)
		{
		}

		public GuiInputCtrl(string pName, bool pRegister = false)
			: this(false)
		{
			Name = pName;
			if (pRegister) registerObject();
		}

		public GuiInputCtrl(string pName, string pParent, bool pRegister = false)
         : this(pName, pRegister)
		{
			CopyFrom(Sim.FindObject<SimObject>(pParent));
		}

		public GuiInputCtrl(string pName, SimObject pParent, bool pRegister = false)
         : this(pName, pRegister)
		{
			CopyFrom(pParent);
		}

		public GuiInputCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiInputCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

		protected override void CreateSimObjectPtr()
		{
			ObjectPtr = InternalUnsafeMethods.GuiInputCtrl_create();
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiInputCtrl_create();
         private static _GuiInputCtrl_create _GuiInputCtrl_createFunc;
         internal static IntPtr GuiInputCtrl_create()
         {
         	if (_GuiInputCtrl_createFunc == null)
         	{
         		_GuiInputCtrl_createFunc =
         			(_GuiInputCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiInputCtrl_create"), typeof(_GuiInputCtrl_create));
         	}
         
         	return  _GuiInputCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion


      #region Properties
      
      
      
      #endregion

	}
}
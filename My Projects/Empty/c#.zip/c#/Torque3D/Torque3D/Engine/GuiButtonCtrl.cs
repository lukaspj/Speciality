using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiButtonCtrl : GuiButtonBaseCtrl
	{
		public GuiButtonCtrl(bool pRegister = false)
			: base(pRegister)
		{
		}

		public GuiButtonCtrl(string pName, bool pRegister = false)
			: this(false)
		{
			Name = pName;
			if (pRegister) registerObject();
		}

		public GuiButtonCtrl(string pName, string pParent, bool pRegister = false)
         : this(pName, pRegister)
		{
			CopyFrom(Sim.FindObject<SimObject>(pParent));
		}

		public GuiButtonCtrl(string pName, SimObject pParent, bool pRegister = false)
         : this(pName, pRegister)
		{
			CopyFrom(pParent);
		}

		public GuiButtonCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiButtonCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

		protected override void CreateSimObjectPtr()
		{
			ObjectPtr = InternalUnsafeMethods.GuiButtonCtrl_create();
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiButtonCtrl_create();
         private static _GuiButtonCtrl_create _GuiButtonCtrl_createFunc;
         internal static IntPtr GuiButtonCtrl_create()
         {
         	if (_GuiButtonCtrl_createFunc == null)
         	{
         		_GuiButtonCtrl_createFunc =
         			(_GuiButtonCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiButtonCtrl_create"), typeof(_GuiButtonCtrl_create));
         	}
         
         	return  _GuiButtonCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion


      #region Properties
      
      
      
      #endregion

	}
}
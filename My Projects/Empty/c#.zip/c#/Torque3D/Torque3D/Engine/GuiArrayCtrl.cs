using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiArrayCtrl : GuiControl
	{
		public GuiArrayCtrl(bool pRegister = false)
			: base(pRegister)
		{
		}

		public GuiArrayCtrl(string pName, bool pRegister = false)
			: this(false)
		{
			Name = pName;
			if (pRegister) registerObject();
		}

		public GuiArrayCtrl(string pName, string pParent, bool pRegister = false)
         : this(pName, pRegister)
		{
			CopyFrom(Sim.FindObject<SimObject>(pParent));
		}

		public GuiArrayCtrl(string pName, SimObject pParent, bool pRegister = false)
         : this(pName, pRegister)
		{
			CopyFrom(pParent);
		}

		public GuiArrayCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiArrayCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

		protected override void CreateSimObjectPtr()
		{
			ObjectPtr = InternalUnsafeMethods.GuiArrayCtrl_create();
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiArrayCtrl_create();
         private static _GuiArrayCtrl_create _GuiArrayCtrl_createFunc;
         internal static IntPtr GuiArrayCtrl_create()
         {
         	if (_GuiArrayCtrl_createFunc == null)
         	{
         		_GuiArrayCtrl_createFunc =
         			(_GuiArrayCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiArrayCtrl_create"), typeof(_GuiArrayCtrl_create));
         	}
         
         	return  _GuiArrayCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion


      #region Properties
      
      
      
      #endregion

	}
}
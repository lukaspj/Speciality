﻿namespace Torque3D.Util
{
   public enum _TamlFormatMode
   {
      Invalid,
      Xml,
      Binary,
      //JSON,
   }
}

﻿namespace Torque3D.Util
{
   public enum GuiTSRenderStyles
   {
      Standard,
      SideBySide,
      Separate
   }
}

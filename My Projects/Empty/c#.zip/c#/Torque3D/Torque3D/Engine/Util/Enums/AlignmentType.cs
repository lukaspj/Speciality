﻿namespace Torque3D.Util
{
   public enum AlignmentType
   {
      AlignNone,
      AlignPosX,
      AlignPosY,
      AlignPosZ,
      AlignNegX,
      AlignNegY,
      AlignNegZ
   }
}

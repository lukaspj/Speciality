﻿namespace Torque3D.Util
{
   public enum CoverPointSize
   {
      Prone,
      Crouch,
      Stand
   }

   public enum NavMeshWaterMethod
   {
      Ignore,
      Solid,
      Impassable
   }
}

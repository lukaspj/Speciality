﻿namespace Torque3D.Util
{
   public enum GuiFontCharset
   {
      ANSI,
      SYMBOL,
      SHIFTJIS,
      HANGEUL,
      HANGUL,
      GB2312,
      CHINESEBIG5,
      OEM,
      JOHAB,
      HEBREW,
      ARABIC,
      GREEK,
      TURKISH,
      VIETNAMESE,
      THAI,
      EASTEUROPE,
      RUSSIAN,
      MAC,
      BALTIC
   }
}

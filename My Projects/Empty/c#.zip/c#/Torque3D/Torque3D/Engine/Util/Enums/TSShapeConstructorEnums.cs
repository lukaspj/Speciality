﻿namespace Torque3D.Util
{
   public enum TSShapeConstructorUpAxis
   {
      X_Axis,
      Y_Axis,
      Z_Axis,
      Default
   }

   public enum TSShapeConstructorLodType
   {
      DetectDTS,
      SingleSize,
      TrailingNumber
   }
}

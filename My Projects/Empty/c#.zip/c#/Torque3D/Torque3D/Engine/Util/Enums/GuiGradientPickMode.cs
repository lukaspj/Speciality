﻿namespace Torque3D.Util
{
   public enum GuiGradientPickMode
   {
      HorizontalColor,
      HorizontalAlpha
   }
}

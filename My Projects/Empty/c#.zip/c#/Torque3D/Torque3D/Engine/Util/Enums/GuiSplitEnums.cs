﻿namespace Torque3D.Util
{
   public enum GuiSplitOrientation
   {
      Vertical,
      Horizontal
   }
   public enum GuiSplitFixedPanel
   {
      Vertical,
      Horizontal
   }
}

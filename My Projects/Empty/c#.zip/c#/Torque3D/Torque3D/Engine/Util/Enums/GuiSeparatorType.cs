﻿namespace Torque3D.Util
{
   public enum GuiSeparatorType
   {
      Vertical,
      Horizontal
   }
}

﻿namespace Torque3D.Util
{
   public enum TurretShapeFireLinkType
   {
      FireTogether,
      GroupedFire,
      IndividualFire
   }
}

﻿namespace Torque3D.Util
{
   public enum GuiAlignmentType
   {
      Left,
      Center,
      Right,
      Top,
      Bottom
   }
}

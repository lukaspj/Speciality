﻿namespace Torque3D.Util
{
   public enum GuiIconButtonTextLocation
   {
      None,
      Bottom,
      Right,
      Top,
      Left,
      Center
   }
}

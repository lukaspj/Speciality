﻿namespace Torque3D.Util
{
   public enum ParticleBlendStyle
   {
      Normal,
      Additive,
      Subtractive,
      PremultAlpha
   }
}

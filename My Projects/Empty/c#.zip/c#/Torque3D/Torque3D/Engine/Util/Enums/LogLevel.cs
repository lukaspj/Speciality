﻿namespace Torque3D.Util
{
   public enum LogLevel
   {
      Normal,
      Warning,
      Error
   }
}

﻿namespace Torque3D.Util
{
   public enum GuiColorPickMode
   {
      Pallete,
      HorizontalColor,
      VerticalColor,
      HorizontalBrightnessColor,
      VerticalBrightnessColor,
      BlendColor,
      HorizontalAlpha,
      VerticalAlpha,
      Dropper
   }
}

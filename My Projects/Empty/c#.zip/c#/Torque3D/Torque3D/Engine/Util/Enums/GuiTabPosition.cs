﻿namespace Torque3D.Util
{
   public enum GuiTabPosition
   {
      Top,
      Bottom
   }
}

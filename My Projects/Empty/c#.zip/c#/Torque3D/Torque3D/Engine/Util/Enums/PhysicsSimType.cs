﻿namespace Torque3D.Util
{
   public enum PhysicsSimType
   {
      ClientOnly,
      ServerOnly,
      ClientServer
   }
}

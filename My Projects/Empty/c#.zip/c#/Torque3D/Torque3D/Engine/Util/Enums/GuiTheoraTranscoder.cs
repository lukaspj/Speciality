﻿namespace Torque3D.Util
{
   public enum GuiTheoraTranscoder
   {
      Auto,
      Generic,
      SSE2420RGBA
   }
}

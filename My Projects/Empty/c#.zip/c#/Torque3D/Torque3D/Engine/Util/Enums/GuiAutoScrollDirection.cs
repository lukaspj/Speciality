﻿namespace Torque3D.Util
{
   public enum GuiAutoScrollDirection
   {
      Up,
      Down,
      Left,
      Right
   }
}

﻿namespace Torque3D.Util
{
   public enum GuiBitmapMode
   {
      Stretched,
      Centered
   }
}

﻿namespace Torque3D.Util
{
   public enum baseTexFormat
   {
      None,
      DDS,
      PNG,
      JPG
   }
}

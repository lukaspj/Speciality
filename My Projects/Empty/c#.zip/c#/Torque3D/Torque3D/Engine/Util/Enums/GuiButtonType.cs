﻿namespace Torque3D.Util
{
   public enum GuiButtonType
   {
      Push,
      Check,
      Radio
   }
}

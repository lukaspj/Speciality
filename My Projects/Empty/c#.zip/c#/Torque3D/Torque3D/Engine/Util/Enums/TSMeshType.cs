﻿namespace Torque3D.Util
{
   public enum TSMeshType
   {
      None,
      Bounds,
      CollisionMesh,
      VisibleMesh,
   }
}

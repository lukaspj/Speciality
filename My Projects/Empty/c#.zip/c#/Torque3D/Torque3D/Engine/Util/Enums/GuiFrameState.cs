﻿namespace Torque3D.Util
{
   public enum GuiFrameState
   {
      AlwaysOn,
      AlwaysOff,
      Dynamic
   }
}

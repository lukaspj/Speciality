﻿namespace Torque3D.Util
{
   public enum ForestBrushMode
   {
      Paint,
      Erase,
      EraseSelected
   }
}

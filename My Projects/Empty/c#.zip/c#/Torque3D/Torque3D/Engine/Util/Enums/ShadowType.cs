﻿namespace Torque3D.Util
{
   public enum ShadowType
   {
      Spot,
      PSSM,
      Paraboloid,
      DualParaboloidSinglePass,
      DualParaboloid,
      CubeMap
   }
}

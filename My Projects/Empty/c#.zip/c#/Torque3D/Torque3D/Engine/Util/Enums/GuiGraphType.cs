﻿namespace Torque3D.Util
{
   public enum GuiGraphType
   {
      Bar,
      Filled,
      Point,
      Polyline
   }
}

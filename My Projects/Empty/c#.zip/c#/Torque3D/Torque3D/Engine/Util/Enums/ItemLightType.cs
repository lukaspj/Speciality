﻿namespace Torque3D.Util
{
   public enum ItemLightType
   {
      NoLight,
      ConstantLight,
      PulsingLight
   }
}

﻿namespace Torque3D.Util
{
   public enum MarkerKnotType
   {
      Normal,
      PositionOnly,
      Kink
   }
   public enum MarkerSmoothingType
   {
      Spline,
      Linear
   }
}

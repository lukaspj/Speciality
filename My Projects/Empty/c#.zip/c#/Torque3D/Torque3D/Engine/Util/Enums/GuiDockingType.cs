﻿namespace Torque3D.Util
{
   public enum GuiDockingType
   {
      None,
      Client,
      Top,
      Bottom,
      Left,
      Right
   }
}

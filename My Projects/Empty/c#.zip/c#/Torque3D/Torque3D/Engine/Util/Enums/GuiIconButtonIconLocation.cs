﻿namespace Torque3D.Util
{
   public enum GuiIconButtonIconLocation
   {
      None,
      Left,
      Right,
      Center
   }
}

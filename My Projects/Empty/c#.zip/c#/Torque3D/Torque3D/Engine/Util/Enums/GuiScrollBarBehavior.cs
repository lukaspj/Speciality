﻿namespace Torque3D.Util
{
   public enum GuiScrollBarBehavior
   {
      AlwaysOn,
      AlwaysOff,
      Dynamic
   }
}
